import {
  tidyShortAnswerV2,
  tidyShortAnswer,
} from "../components/my_content/question_forms/questionFormValues.js";

describe("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed all the different types of subType.", () => {
  test("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed a valid short answer question with a subType of 'wordOrPhrase'", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "wordOrPhrase",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { text: "Paris" },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed a valid short answer question with a subType of 'text'", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "text",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { text: "Paris" },
      acceptAlternateSpacing: true,
      acceptAlternateCapitalization: true,
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 returns the same object  when passed a valid short answer question with a subType of 'number'", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "number",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { number: 2, percentTolerance: 0.1 },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 returns correct values object when passed a valid short answer question with a subType of 'measurement'", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "measurement",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { number: 2, unit: "m", percentTolerance: 0.1 },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed a valid short answer question with a subType of 'expr'.", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "expr",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { expr: "Paris" },
      options: { evaluationTimeout: 1, allowModification: true },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed a valid short answer question with a subType of 'mathematica expression'.", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "mathematica expression",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { expr: "Paris" },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed a valid short answer question with a subType of 'mathematica list'.", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "mathematica expression",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { text: "Paris" },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed a valid short answer question with a subType of 'vector'.", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "vector",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { vector: "{1}", percentTolerance: 0.1 },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed a valid short answer question with a subType of 'vector with unit'.", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "vector with unit",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { vector: "{1}", unit: "m", percentTolerance: 0.1 },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed a valid short answer question with a subType of 'vector expr'.", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "vector expr",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { vectorExpr: "{1}" },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });

  test("tidyShortAnswerV2 and tidyShortAnswer return the same values object when passed a valid short answer question with a subType of 'chemical formula'.", () => {
    const validShortAnswerQuestion = {
      type: "shortAnswer",
      subtype: "chemical formula",
      prompt: "What is the capital of France?",
      possiblePoints: 10,
      attemptsAllowed: 3,
      tags: ["France", "capital"],
      solution: "Paris.pdf",
      auxillaryFiles: ["Paris.pdf"],
      match: "exact",
      correctAnswer: { chemFormula: "H2O" },
    };

    expect(tidyShortAnswerV2(validShortAnswerQuestion)).toEqual(
      tidyShortAnswer(validShortAnswerQuestion)
    );
  });
});
